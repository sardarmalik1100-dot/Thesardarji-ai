SARDAR AI — FREE STARTER WEBSITE

What is included:
- Responsive dark premium interface for mobile and desktop
- Chat interface with locally generated demo responses
- New chat and recent-chat list for the current browser session
- Writing, summarizer, translator, and coding-helper demo modes

Important:
This is a working front-end prototype, NOT a real AI chatbot yet. It does not call an AI model, and its responses are local demo messages. To get real AI answers, connect an AI provider through a secure serverless/backend function. Never put a secret API key in index.html or other public browser code.

How to preview:
1. Extract the ZIP.
2. Open index.html in a browser.

How to publish free using GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. sardar-ai.
3. Upload index.html to the repository root.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. After deployment, GitHub shows the public website URL in the Pages section.

No paid domain is needed for the initial version. GitHub account and hosting terms/limits apply.
